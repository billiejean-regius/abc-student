// game.js

let mapWidth = 300;
let mapHeight = 300;

let minDist = 50;

let player; 

let currentLoopIndex = 0;
const animationLoop = [1, 2, 3, 4]

// let displayBox = document.createElement('div');
// displayBox.setAttribute('id', 'displayBox');

let gameMap = document.createElement('div');
gameMap.setAttribute('id', 'gameMap');
gameMap.style.width = mapWidth  + 'px';
gameMap.style.height = mapHeight + 'px';

document.body.append(gameMap);

let activePlayers = [];
let activeObjects = [];
let activeFlowers = [];

const leftKey = "ArrowLeft";
let faceLeft = false;
const rightKey = "ArrowRight";
let faceRight = false;
const upKey = "ArrowUp";
let faceUp = false;
const downKey = "ArrowDown";
let faceDown = false;

window.onkeydown = function(event) {
  const keyCode = event.key;
  event.preventDefault();

    if(keyCode == leftKey) {  
      player.stepLeft();
    } else if(keyCode == rightKey) {
      player.stepRight();
    } else if(keyCode == upKey) {
      player.stepUp();
    } else if(keyCode == downKey) {
      player.stepDown();
    } 
}

// Game Objects & Players
class Player {
  constructor(posX, posY, playerId, isMe) {
      // this.posX = 0; // for debugging
      // this.posY = 0; // for debugging
      this.posX = posX; // x position
      this.posY = posY; // y position
      this.width = 24;
      this.height = 36;
      this.playerId = playerId; // socket.id
      this.speed = 2; // # of px moved
      this.isMe = isMe; // true or false
      this.elm; 
      this.myFlowers = []; // flower inventory
      this.giftTo;
      this.collisionMarker;
      this.playerPanel;
      this.reactionTop;
  }
  
  stepRight(){
    faceRight = true;
    // check if step would collide
    if( this.isColliding(this.posX + this.speed, this.posY) == true ){

    }else{
      this.posX = this.posX + this.speed;
      socket.emit('playerMovement', ({x: this.posX, y: this.posY})); 
      this.updatePosition();

      if(this.isCollectingFlower(this.posX, this.posY) == true) {
        // console.log('pickup the flower');
      }
      if(this.isWithinReach(this.posX, this.posY) == true) {
        // console.log("you can gift a flower");
      }
    }
    // if not
    // apply step to this.posX 
    // update the DOM (gameMap)
    // tell server that player moved
  }
  stepLeft() {
    faceLeft = true;
    if( this.isColliding(this.posX - this.speed, this.posY) == true ){

    }else{
      this.posX = this.posX - this.speed;
      socket.emit('playerMovement', ({x: this.posX, y: this.posY})); 
      this.updatePosition();

      if(this.isCollectingFlower(this.posX, this.posY) == true) {
        // console.log('pickup the flower');
      }
      if(this.isWithinReach(this.posX, this.posY) == true) {
        // console.log("you can gift a flower");
      }
    }

  }
  stepUp() {
    faceUp = true;
    if( this.isColliding(this.posX, this.posY - this.speed) == true ){

    }else{
      this.posY = this.posY - this.speed;
      socket.emit('playerMovement', ({x: this.posX, y: this.posY})); 
      this.updatePosition();

      if(this.isCollectingFlower(this.posX, this.posY) == true) {
        // console.log('pickup the flower');
      }
      if(this.isWithinReach(this.posX, this.posY) == true) {
        // console.log("you can gift a flower");
      }
    }

  }
  stepDown() {
    faceDown = true;
    if( this.isColliding(this.posX, this.posY + this.speed) == true ){

    }else{
      this.posY = this.posY + this.speed;
      socket.emit('playerMovement', ({x: this.posX, y: this.posY})); 
      this.updatePosition();

      if(this.isCollectingFlower(this.posX, this.posY) == true) {
        // console.log('pickup the flower');
      }
      if(this.isWithinReach(this.posX, this.posY) == true) {
        // console.log("you can gift a flower");
      }
    }

  }
  isColliding(nextStepX, nextStepY) {
    //    - bounds of map
    if(nextStepX >= 0 && nextStepX < mapWidth - this.width && nextStepY >= 0 && nextStepY < mapHeight - this.height) {
    //    - other players
      for(let i = 0; i < activePlayers.length; i++) {
        
        if(activePlayers[i].playerId != this.playerId) {
         // other
         let other = activePlayers[i];
         if((other.posX > nextStepX - other.width) && 
            (other.posX <= nextStepX + this.width) && 
            (other.posY > nextStepY - other.height) && 
            (other.posY <= nextStepY + this.height) ) {
              return true
          }
        }
        // console.log(activePlayers[i]);      
      }
       return false
    } else {
      return true
    }
  }
  isCollectingFlower(nextStepX, nextStepY) { //does not actually use the next step uses where they are
    for(let i = 0; i < activeFlowers.length; i++) {
      let theFlower = activeFlowers[i];
      if((theFlower.posX > nextStepX - theFlower.width) && 
      (theFlower.posX <= nextStepX + this.width) && 
      (theFlower.posY > nextStepY - theFlower.height) && 
      (theFlower.posY <= nextStepY + this.height) ) {
        // console.log(activeFlowers[i].name);

        // set isPicked to true
          activeFlowers[i].isPicked = true;
          activeFlowers[i].whoPicked = this.playerId;
          // console.log(this.playerId, ' picked ', activeFlowers[i].id)
        
        // emit to server
          socket.emit('flowerCollected', activeFlowers[i]);

        // move to players inventory
          this.myFlowers.push(activeFlowers[i]);
          // console.log(this.myFlowers);

           /// Move to a socket function?
            // for(let i=0; i < this.myFlowers.length; i++) {
            //   // console.log(this.myFlowers[i]);
            //   //add the image of flower 1 to grid id 1, 2 to 2
            //   let gridNum = 'flwr' + (i + 1);
            //   let getGrid = document.getElementById(gridNum);
            //   getGrid.style.backgroundImage = this.myFlowers[i].flwrIcon;
            // }
        
        return true
      }
    } 
  }
  isWithinReach(myPosX, myPosY) {
  
    if(this.myFlowers.length < 1) {
      // console.log("no flowers to give")
    } else {
      for(let i = 0; i < activePlayers.length; i++) {
          
        if(activePlayers[i].playerId != this.playerId) {
        // other
        let other = activePlayers[i];
        while((other.posX > myPosX - other.width - minDist) && 
            (other.posX <= myPosX + this.width + minDist) && 
            (other.posY > myPosY - other.height - minDist) && 
            (other.posY <= myPosY + this.height + minDist) ) {

              // reaction pops up when you are close enough to give a flower
              this.reactionTop.setAttribute('class', 'reactionOne');
              this.reactionTop.style.backgroundImage = 'url(assets/rabillion/reactions/exclamation.png)'

              // emit to server
              // who is sending the flower => this.playerId
              // what flower => first flower in this.myFlowers?
              // to who => activePlayers[i].playerId
              this.giftTo = activePlayers[i].playerId;
              let playerIsGifting = activePlayers.find(player => player.playerId === this.playerId);
              // console.log(this.playerId, ' wants to gift ', activePlayers[i].playerId, ' a flower');
              socket.emit('giftingFlower', playerIsGifting);

              // return true
            }
          // } else {
          this.reactionTop.classList.remove('reactionOne');
            
          // }
        }
        // console.log(activePlayers[i]);      
      }
    } 
  }
  updatePosition() {
    // if me:
    if(this.isMe === true) {
      gameMap.style.left = - this.posX  + 'px';
      gameMap.style.top = - this.posY  + 'px';
    } else {
      this.elm.style.left = this.posX + 'px';
      this.elm.style.top = this.posY  + 'px';
    }
    // else:
    // move actal this.elm to location
  }
  createElement(){
    this.elm = document.createElement('div');
    this.collisionMarker = document.createElement('div');
    this.playerPanel = document.createElement('div');
    this.reactionTop = document.createElement('div');
    // if me....
    if(this.isMe === true) {
      this.elm.setAttribute('class', 'mainPlayer');
      this.collisionMarker.setAttribute('class', 'myMarker');
      this.playerPanel.setAttribute('class', 'myPanel');
    // if not me...
    } else {
      this.elm.setAttribute('class', 'otherPlayer');
      this.collisionMarker.setAttribute('class', 'otherMarker');
      this.playerPanel.setAttribute('class', 'otherPanel');
    }
    // else
    //  ///
    // assign element id as the socket id
      this.elm.id =  this.playerId;
      
      this.elm.style.width = this.width + 'px';
      this.elm.style.height = this.height + 'px';

      // append the mainPlayer to the map
      gameMap.append(this.elm)

      this.collisionMarker.style.width = 15 + 'px';
      this.collisionMarker.style.height = 7 + 'px';
      this.collisionMarker.style.top = 20 + 'px';
      this.collisionMarker.style.left = 4.5 + 'px';

      this.elm.append(this.collisionMarker, this.playerPanel);

      let flowerDisplay = document.createElement('div');
        flowerDisplay.setAttribute('class', 'flowerDisplay');

      for(let i=0; i<10; i++) {
        let flwrInventory = document.createElement('div');
          flwrInventory.setAttribute('id', 'flwr' + (i + 1));
          flwrInventory.setAttribute('class', 'flwr');

        flowerDisplay.append(flwrInventory);
      }
      
      // let reactionOne = document.createElement('div');
      // reactionOne.setAttribute('class', 'reactionOne');
      // reactionOne.style.backgroundImage = 'url(assets/rabillion/reactions/exclamation.png)'
      

      // this.elm.append(playerPanel, collisionMarker);
        this.playerPanel.append(this.reactionTop, flowerDisplay);


    // sprite sheet
      let sheet = new Image();
      sheet.src = 'assets/rabillion/sheet/walk_back.front.png';

      this.elm.style.backgroundImage = 'url(assets/rabillion/sheet/walk_back.front.png)';
    
      
    // name tag for debug tracking
      // let nameTag = document.createElement("p");
      // nameTag.innerHTML = this.playerId;
      // this.elm.append(nameTag)

     // set map coordinates from random player location
      this.updatePosition();
  }
  myFlowers() {
    this.elm = document.createElement('div');

  }
  drawSprite(frameX, frameY) {
    let spriteX = frameX * this.width;
    let spriteY = frameY * this.height;
    this.elm.style.backgroundPosition = `${spriteX}px ${spriteY}px`;
  }
};

class worldObject {
    constructor(name, id, posX, posY, width, height) {
        this.name = name;
        this.id = id;
        this.posX = posX;
        this.posY = posY;
        this.width = width;
        this.height = height;
    }
  };
  
  class Flower extends worldObject { 
    constructor (name, id, posX, posY, isPicked, flwrImage, flwrIcon) {
        super(name, id, posX, posY); 
        // this.scientific = scientific;
        // this.rarity = rarity;
        this.posX = posX;
        this.posY = posY;
        this.width = 14;
        this.height = 22;
        this.flowerElm;
        this.isPicked = isPicked;
        this.whoPicked;
        this.flwrImage = flwrImage;
        this.flwrIcon = flwrIcon;
    }
    createElement(){
      this.flowerElm = document.createElement('div');

      this.flowerElm.setAttribute('class', 'flower');
      this.flowerElm.setAttribute('id', this.id);

      this.flowerElm.style.width = this.width + 'px';
      this.flowerElm.style.height = this.height + 'px';

      this.flwrIcon = 'url(assets/world/blueFlowerIcon.png)'
      this.flwrImage = 'url(assets/world/blueFlowerPlant.png)';
      this.flowerElm.style.backgroundImage = this.flwrImage;

      gameMap.append(this.flowerElm)

      this.updatePosition();
    }
    updatePosition() {
      this.flowerElm.style.left = this.posX + 'px';
      this.flowerElm.style.top = this.posY  + 'px';
    }
  };

  // let flowers = [
  //   ghostOrchid = new Flower ("Ghost Orchid", "Dendrophylax Lindenii", 10, randomPosition() - 5, randomPosition() - 5, 10, 10),
  // ];

let socket = io();
 
socket.on('currentPlayers', function (players) {
  Object.keys(players).forEach(function (id) {
    // me:
    if (players[id].playerId === socket.id) {
      // create an asset for the main player
      if(activePlayers.indexOf(socket.id) === -1) {
        // console.log("adding main player");
        // addPlayer(players[id]);
        player = new Player (players[id].x, players[id].y, players[id].playerId, true);
        // push player (mainPlayer) instance to activePlayers array
        activePlayers.push(player);
        // create mainPlayer element 
        player.createElement();
      }
      // or them:
    } else {
      // otherwise, create an other player
      if(activePlayers.indexOf(socket.id) === -1) {
        // console.log("adding other player");
        // addOtherPlayers(players[id]);
        let guestPlayer = new Player (players[id].x, players[id].y, players[id].playerId, false);
        // push player (mainPlayer) instance to activePlayers array
        activePlayers.push(guestPlayer);
        // create mainPlayer element 
        guestPlayer.createElement();
      }
    }
  });
  // console.log(activePlayers);
});
socket.on('newPlayer', function (playerInfo) {
  console.log("A new player has joined");
  // addOtherPlayers(playerInfo);
  let guestPlayer = new Player (playerInfo.x, playerInfo.y, playerInfo.playerId, false);
  // push player (mainPlayer) instance to activePlayers array
  activePlayers.push(guestPlayer);
  // create mainPlayer element 
  guestPlayer.createElement();
});
socket.on('playerMoved', function (playerInfo) {
  // console.log("a player moved");

  // console.log('delete this: ', players[i].playerId.indexOf(socket.id));
  let movedPlayer = activePlayers.find(player => player.playerId === playerInfo.playerId);
  // console.log(movedPlayer);

  movedPlayer.posX = playerInfo.x;
  movedPlayer.posY = playerInfo.y;

  movedPlayer.updatePosition();
});
socket.on('flowerData', function (flowerData) {
  for(let i=0; i < 5; i++) {
    // console.log(flowerData[i].x, flowerData[i].y);
    let flower = new Flower ('a flower', flowerData[i].id, flowerData[i].x, flowerData[i].y, flowerData[i].isPicked);

    activeFlowers.push(flower);
    // create mainPlayer element 
    flower.createElement();
  }
});

socket.on('someonePickedTheFlower', function (playerPicked) {
  console.log(playerPicked.whoPicked, ' picked ', playerPicked.id);

   // remove from active flower objects
   activeFlowers.splice(playerPicked.id, 1);
  //  console.log(activeFlowers);

   // remove from gameMap
    // console.log(theFlower.id);
    let flowerToRemove = document.getElementById(playerPicked.id);
    gameMap.removeChild(flowerToRemove);

    let thePicker = document.getElementById(playerPicked.whoPicked);
    // console.log(thePicker);

  //   for(let i=0; i < thePicker.myFlowers.length; i++) {
  //     // console.log(this.myFlowers[i]);
  //     //add the image of flower 1 to grid id 1, 2 to 2
  //     let gridNum = 'flwr' + (i + 1);
  //     let getGrid = document.getElementById(gridNum);
  //     getGrid.style.backgroundImage =  thePicker.myFlowers[playerPicked.id].flwrIcon;
  //  }
});

socket.on('newFlower', function (newFlower) {
  // console.log(newFlower.x, newFlower.y);
  let flower = new Flower ('a flower', newFlower.id, newFlower.x, newFlower.y, newFlower.isPicked);
  activeFlowers.push(flower);
  flower.createElement();
  console.log('a new flower is growing!');
});

socket.on('disconnectUser', function (playerId) {
    // remove the div element of the disconnected player
    let el = document.getElementById(playerId);
    // console.log(el);
    el.remove(gameMap);

    console.log(activePlayers);
    for(let i = 0; i < activePlayers.length; i++) {
      // console.log('delete this: ', players[i].playerId.indexOf(socket.id));
      let disconnectedPlayer = activePlayers[i].playerId.indexOf(socket.id);
      activePlayers.splice(disconnectedPlayer, 1);
    }

    console.log("A player has left the game");
});















