## Exercise (placeholder)

In this exercise I encountered
- problems
and
- learned things
...

See my work [here](). (note this link goes to GitHub Pages, the *public* face of this project)
̨
