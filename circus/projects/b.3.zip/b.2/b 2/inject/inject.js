var innards = document.body.innerHTML;
document.body.innerHTML += innards;

// $(window).scroll(function (e){
//   if ($(document).height() < $(window).scrollTop() + $(window).height() * 10){
//     document.body.innerHTML += innards;
//   }
// });

// create game banner 
let banner = document.createElement('div');
banner.setAttribute('id', 'gameBanner');
// create frog as player
let froggy = document.createElement('div');
froggy.setAttribute('id', 'froggy');
// append banner and player
document.body.appendChild(banner);
banner.appendChild(froggy);

// time counter
let timeBanner = document.createElement('div');
timeBanner.setAttribute('id', 'timeBanner');
document.body.appendChild(timeBanner);

let seconds = 60;
let timer;

// get all tag elements 
let tags = document.getElementsByTagName("a");
console.log(Array.from(document.getElementsByTagName("a")));
tagsArray = [];

tagsArray.push(); //add new tags 
tagsArray.splice(); //remove or replace aging tags

const getOffset = (el) => {
  const rect = el.getBoundingClientRect();
  return {
    left: rect.left,
    top: rect.top,
    width: rect.width,
    height: rect.height,
  };
}
let a = getOffset(froggy).left;
console.log(a);

 // console.log(isFroggyColliding(a, b));

const leftKey = "ArrowLeft";
const rightKey = "ArrowRight";

window.onkeydown = function(event) {
  const keyCode = event.key;
  event.preventDefault();
  if(keyCode == "ArrowLeft") {
    updateOffset();
    console.log("I moved left", a);
    // console.log("Left arrow")
    froggy.style.left = (froggy.offsetLeft + -10) + 'px';
  } else if(keyCode == "ArrowRight") {
    updateOffset();
    console.log("I moved right", a);
    // console.log("Right arrow")
    froggy.style.left = (froggy.offsetLeft + 10) + 'px';
  }
}

function isFroggyColliding(a, b) {
  return !(
      ((a.top + a.height) < (b.top)) || //froggy.top + froggy.height < tags.top
      (a.top > (b.top + b.height)) || //froggy.top > tags.top + tags.height
      ((a.left + a.width) < b.left) || //froggy.left + froggy.width < tags.left
      (a.left > (b.left + b.width)) //froggy.left > tags.left + tags.width
  );
} // https://codepen.io/mixal_bl4/pen/qZYWOm

function updateOffset() {
  console.log(getOffset(froggy).left);
}

// countdown timer function
function gameTimer() {
  if(seconds < 60){
   timeBanner.innerHTML = "NOW YOU HAVE "+ seconds +" LEFT";
    // let node = document.createTextNode ("NOW YOU HAVE "+ seconds +" SECONDS LEFT TO PASS THE GAME");
    // timeBanner.appendChild(node);
    console.log("NOW YOU HAVE "+ seconds +" LEFT");

    console.log(timeBanner);
  }
  if (seconds >0){
    seconds--;
  } else {
    clearInterval(timer);
  }
}

timer = window.setInterval(function() {
      gameTimer();
    }, 1000);


  function infiniteScroll(){
    // make red 
    for(let i = 0; i < tags.length; i++){
      if(tags[i].textContent != "" && getOffset(tags[i]).top != 0){
        tags[i].style.color = "red";
        tags[i].style.outline = "1px solid blue"
      }
      if(getOffset(tags[i]).top < 400){
        // console.log("i am done!");
        tags[i].style.color = "blue";
      }
    }
    // setTimeout(function(){
    // window.scrollBy(0, 2);
    // }, 10)
  }
//document.addEventListener('click', infiniteScroll);
setInterval(infiniteScroll,100);

// //solution1: make the scroll-down into a larger scale
let intervalCount = 1;
let maxInterval = 15;
let countedInterval = setInterval(()=>{
  window.scrollBy(0, intervalCount);
  console.log("This is", intervalCount);
   if(intervalCount > maxInterval){
     clearInterval(countedInterval);
     alert("Game is over now!");
   }
   //intervalCount++;
}, 40)

setTimeout(function(){
  intervalCount =  intervalCount + 4
}, 5000);

setTimeout(function(){
  intervalCount =  intervalCount + 8
}, 10000)

setTimeout(function(){
  intervalCount =  intervalCount + 12
}, 15000)
// addEventListener("click", function(){
//   intervalCount =  intervalCount + 6
// });
console.log(intervalCount);

//references 
// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/from
// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/parseInt
// https://developer.mozilla.org/en-US/docs/Web/API/Element/keydown_event
// https://stackoverflow.com/questions/23585320/how-to-move-object-with-keyboard-in-javascript
// http://jsfiddle.net/medda86/y6WU9/
// https://stackoverflow.com/questions/10445410/getting-the-x-and-y-coordinates-for-a-div-element#:~:text=If%20the%20element%20is%20in,')%3B%20let%20Y%3Dwindow.
// https://dustinpfister.github.io/2019/03/14/canvas-position/
// https://github.com/chjno/100days/tree/master/62_infinite_scroll
// https://stackoverflow.com/questions/2440377/javascript-collision-detection
// https://codepen.io/mixal_bl4/pen/qZYWOm


