# ABC Browser Circus 🎪 Project A

My project explores interaction between devices, or more precisely, perceived communication created through reading tarot cards. The project is currently played through three mobile devices, with several tones indicating when and how the user should interact with the “cards.”

Challenges and Shortcomings 
I certainly struggled with understanding the correct structure, as most problems I have encountered are simple structural problems. Furthermore, I tend to commit to much time to developing concepts and frameworks for parts of the project that might not be incorporated into the final project. 
For future iterations of this project, I will attempt to implement QR codes so that the system can feed information to various pages, without the devices being connected. 

